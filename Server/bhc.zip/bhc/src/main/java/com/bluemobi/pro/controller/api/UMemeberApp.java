package com.bluemobi.pro.controller.api;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.bluemobi.cache.CacheService;
import com.bluemobi.constant.Constant;
import com.bluemobi.constant.ErrorCode;
import com.bluemobi.pro.service.impl.MemberService;
import com.bluemobi.utils.CommonUtils;
import com.bluemobi.utils.ResultUtils;
import com.bluemobi.utils.SmsApi;
import com.bluemobi.utils.UploadUtils;
import com.qiniu.util.StringMap;

@Controller
@RequestMapping("/app/member/")
public class UMemeberApp {

	@Autowired
	private MemberService service;

	@Resource(name = "cacheTempCodeServiceImpl")
	private CacheService<String> cacheService;

	@RequestMapping(value = "validate", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> validate(@RequestParam Map<String, Object> params) {

		Map<String, Object> respMap = new HashMap<String, Object>();
		int isExist = 0;
		try {
			Map<String,Object> userMap = service.isExist(params);
			if(userMap != null && userMap.get("id") != null) {
				// 已注册
				isExist = 1;
				respMap.put("user", userMap);
			}
			respMap.put("isExist", isExist);
		} catch (Exception e) {
			e.printStackTrace();
			return ResultUtils.error();
		}
		return ResultUtils.map2(respMap);
	}

	@RequestMapping(value = "sendCode", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> sendCode(@RequestParam Map<String, Object> params) {
		try {
            // 生成验证码
            String code = CommonUtils.getCode(6);

            String mobile = params.get("mobile").toString();
            // 成功
            if (SmsApi.sendCode(code, mobile)) {
                cacheService.put(mobile,code);
                return ResultUtils.string("");
            }
            // 失败
            else {
                return ResultUtils.error(ErrorCode.ERROR_09);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtils.error(ErrorCode.ERROR_01);
        }
	}

	/**
	 * 注册
	 * 
	 * @param params
	 * @return
	 */
	@RequestMapping(value = "register", method = RequestMethod.POST)
	@ResponseBody
	public Map<String,Object> register(@RequestParam Map<String,Object> params) {
		
		try {
			String code = params.get("code") == null ? "" : params.get("code").toString();
			String mobile = params.get("mobile").toString();
			String sendCode = cacheService.get(mobile);
			if(!"000000".equals(code)){
				if(code == null || StringUtils.isBlank(sendCode) || !code.equals(sendCode)) {
					return ResultUtils.error(ErrorCode.ERROR_10);
				}
			}
			service.register(params);
		} catch (Exception e) {
			e.printStackTrace();
			return ResultUtils.error();
		}
		return ResultUtils.success();
	}

	/**
	 * 登陆
	 * 
	 * @return
	 */
	@RequestMapping(value = "login", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> checkLogin(
			@RequestParam Map<String, Object> params) {

		String token = params.get("token").toString();
		Map<String, Object> userMap = null;
		try {
			userMap = service.login(params);
		} catch (Exception e) {
			e.printStackTrace();
			return ResultUtils.error();
		}
		if (userMap != null && userMap.get("token") != null
				&& token.equals(userMap.get("token"))) {
			return ResultUtils.map(userMap, "user");
		} else {
			return ResultUtils.error(ErrorCode.ERROR_03);
		}
	}

	/**
	 * 发布新消息
	 * 
	 * @param params
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "release", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> release(
			@RequestParam Map<String, Object> params,
			@RequestParam(value = "file", required = false) MultipartFile[] file) {
		try {

			List fileList = new ArrayList();
			if(file != null) {
				for (MultipartFile multipartFile : file) {
					String name = multipartFile.getOriginalFilename();
					int type = confirmFileType(name);
					
					StringMap map = UploadUtils.upload(UploadUtils
							.changeFile(multipartFile));
					String path = Constant.domain + map.get("key");
					Map<String,Object> resource = new HashMap<String, Object>();
					resource.put("linkUrl", path);
					resource.put("type", type);
					fileList.add(resource);
				}
				params.put("linkUrls", fileList);
			}
			service.release(params);
		} catch (Exception e) {
			e.printStackTrace();
			return ResultUtils.error();
		}
		return ResultUtils.success();
	}

	private int confirmFileType(String name) {
		if(name.contains("jpeg") || name.contains("jpg") || name.contains("png")) {
			return 0;
		}
		else if(name.contains("mp4")) {
			return 1;
		}
		return 0;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "findMessage", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> findRelease(
			@RequestParam Map<String, Object> params) {

		try {
			Object respObhect = service.findMessage(params);
			if (respObhect instanceof List) {
				return ResultUtils.list((List) respObhect);
			} else if (respObhect instanceof Map) {
				return ResultUtils.map((Map<String, Object>) respObhect,
						"message");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ResultUtils.error();
		}
		return null;
	}
}
