package com.bluemobi.pro.service.impl;


import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bluemobi.sys.service.BaseService;
import com.bluemobi.utils.UploadUtils;
import com.google.gson.GsonBuilder;

@Service
public class MemberService extends BaseService{

	private static final String PRIFIX = MemberService.class.getName();
	
	// 判断用户是否存在
	public Map<String,Object> isExist(Map<String,Object> params) throws Exception {
		return findMemberByToken(params.get("token").toString());
	}
	
	public Map<String,Object> findMemberByToken(String mobile) throws Exception {
		return this.getBaseDao().getObject(PRIFIX + ".findMemeberByToken", mobile);
	}
	
	// 注册
	public int register(Map<String,Object> params) throws Exception {
		return this.getBaseDao().save(PRIFIX + ".insertUser", params);
	}
	
	// 登陆
	public Map<String,Object> login(Map<String,Object> params) throws Exception {
		String mobile = params.get("mobile").toString();
		Map<String,Object> userMap = findMemberByToken(mobile);
		return userMap;
	}
	
	// 发布新消息
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public int release(Map<String,Object> parmas) throws Exception {
		
		parmas.put("id", 0);
		this.getBaseDao().save(PRIFIX + ".insertMessage", parmas);
		
		Object filelist = parmas.get("linkUrls");
		if(filelist != null) {
			List fileList = (List)filelist ;
			for (Object object : fileList) {
				if(object != null) {
					Map<String,Object> fileMap = (Map<String, Object>) object;
					fileMap.put("messageId", parmas.get("id"));
					this.getBaseDao().save(PRIFIX + ".insertFile", fileMap);
				}
			}
		}
		return 1;
	}
	
	// 查询信息
	@SuppressWarnings("unchecked")
	public Object findMessage(Map<String,Object> params) throws Exception {
		Map<String,Object> map = this.getBaseDao().getObject(PRIFIX + ".findMessage", params);
		if(map == null) return Collections.EMPTY_MAP;
		List<Map<String,Object>> fileList = this.getBaseDao().getList(PRIFIX + ".findResource", map);
		if(fileList != null) {
			for (Map<String, Object> map2 : fileList) {
				Object obj = map2.get("type");
				if(obj != null) {
					int type = Integer.parseInt(obj.toString());
					Object linkUrl = map2.get("linkUrl");
					if(type == 0 && linkUrl != null) {
						String response = UploadUtils.getFileInfo(linkUrl.toString());
						Map<String,Object> map3 = new GsonBuilder().create().fromJson(response, Map.class);
						map2.put("width", map3.get("width"));
						map2.put("height", map3.get("height"));
					}
				}
			}
		}
		
		map.put("linkUrls", fileList == null ? Collections.EMPTY_LIST : fileList);
		return map;
		
	}
}
