package com.bluemobi.utils;

import com.qiniu.common.QiniuException;
import com.qiniu.http.Client;
import com.qiniu.http.Response;

public class HttpClientUtils {

	
	public static void main(String[] args) {
//		post();
	}
}